import React ,{Component} from 'react';

class Counter extends Component{
constructor(props){
  super(props);
  this.state 	= {show:'none',nArray:'',thumbnailUrl:'',url:'',title:'',id:'',albumId:'',a:''};

  this.EditData = this.EditData.bind(this); 
  this.Close = this.Close.bind(this);
  this.updateHandle= this.updateHandle.bind(this);
  this.changeHandle = this.changeHandle.bind(this);
}

 componentDidMount(){	
    this.props.SearchData();
 }

   EditData(idx){
   let newArray = this.props.counter;
   
   this.setState({show:"block"});
   this.setState({nArray:newArray[idx],thumbnailUrl:newArray[idx].thumbnailUrl,url:newArray[idx].url,title:newArray[idx].title,id:newArray[idx].id,albumId:newArray[idx].albumId});                
}
Close(){
 this.setState({show:"none"});
}
updateHandle(event){   
    event.preventDefault(); 
    event.stopPropagation();
 
   this.props.decrement(this.state.nArray);
this.setState({show:"none"});
 
}
 changeHandle(event){
   let ndata = this.state.nArray;
   var name = event.target.name;
   ndata[name]= event.target.value;
   this.setState({nArray:ndata});
}


render(){
  const {counter,decrement,SearchData,Deletedata} = this.props;

return(
        <div>
	
	<div className="w3-container"> 		
		<table style={{fontSize:"12px"}} className="w3-table-all"> 
		  <thead>
		  <tr className="w3-red">	
		  <th>SNO</th>			
		  <th>Id</th>
		  <th>Title</th>	     
		  <th>Url</th>
 		  <th>Thumbnailurl</th>		
		  <th>Action</th>
		  </tr> 
		 </thead>
		  <tbody>	
			{			 
			Object.keys(this.props.counter).map((key, i) => {
			return <tr key={i}><td>{(i+1)} </td><td>{this.props.counter[key].id}</td><td>{this.props.counter[key].title}</td>
		        <td>{this.props.counter[key].url}</td><td>{this.props.counter[key].thumbnailUrl}</td>
		        <td><button onClick={()=>Deletedata(i)}>Delete</button><button onClick={()=>this.EditData(i)}>Edit</button></td>
		        </tr>		        
		  })
	  }	
		  {/*		
			  this.props.mydata.map((item, i) => {
			 return <tr key={i}><td>{(i+1)}</td><td>{item.id}</td><td>{item.title}</td><td>{item.completed}</td></tr>		        
		  })
		  */}
		  </tbody>
		  </table>
  
   { /*
   this.props.mydata.todos.map((item,index)=>{
   return <p>{item[index].title}</p>
	  
  
   })
  */}
  
 </div>
  <Model show={this.state.show} mydata={this.state.nArray} thumbnailUrl={this.state.thumbnailUrl} url={this.state.url} title={this.state.title} albumId={this.state.albumId} id={this.state.id} Close={this.Close} updateHandle={this.updateHandle} changeHandle={this.changeHandle}/>
</div>
);	
}
}

function Model(props) {
  //console.log(props.mydata);
 return(
	<div id="id01" className="w3-modal" style={{display:props.show}}>
	<div className="w3-modal-content">
		<header className="w3-container w3-red"> 
			<span  onClick={props.Close}className="w3-button w3-display-topright">&times;</span>
			<h5>Update</h5>
		</header>
	<div className="w3-container">
		<form className="w3-container" onSubmit={(event)=>props.updateHandle(event)}>		 
			
			  <p>      
			  <label className="w3-text-blue"><b>Title</b></label>
			  <input className="w3-input w3-border" name="title" type="text" value={props.mydata.title} onChange={(e)=>props.changeHandle(e)}/></p>
			  <p>      
			  <label className="w3-text-blue"><b>Url</b></label>
			  <input className="w3-input w3-border" name="url" type="text" value={props.mydata.url} onChange={(e)=>props.changeHandle(e)}/></p>
			<p>      
			<label className="w3-text-blue"><b>ThumbnailUrl</b></label>
			<input className="w3-input w3-border" name="albumId" type="text" value={props.mydata.thumbnailUrl} onChange={(e)=>props.changeHandle(e)}/></p>
			
			<p>      
			  <button className="w3-btn w3-blue">Register</button></p>
		</form>
	</div>
		<footer className="w3-container w3-red">
		<p>Modal Footer</p>
		</footer>
	</div>
	</div>
);

}

export default Counter;
