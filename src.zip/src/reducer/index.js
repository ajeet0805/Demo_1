const reducer =(state=0,action)=>{
 switch(action.type){
	
	case"UPDATE":
                  let sIDx ={...state};
                  let ids = action.payload.id;
		  var size1 = Object.values(sIDx);		   
                     size1[ids]=action.payload;
		return size1;
	
	
	case"SEARCHDATA":       
		return action.payload;
	case"DELETE":
		let newArray = {...state};
		var size = Object.values(newArray);
		size.splice(action.payload,1);      
		return size;
		
     default:
	return 0;
}
}
export default reducer;


