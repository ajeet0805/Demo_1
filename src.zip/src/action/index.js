import axios from 'axios';

export const SearchData = () => {
  return dispatch => {
       axios
      .get(`http://jsonplaceholder.typicode.com/photos?albumId=1` 
      )
      .then(res => {
        dispatch(addTodoStarted(res.data));
      })
      .catch(err => {
        dispatch(addTodoFailure(err.message));
      });
  };
};

const addTodoStarted =todo => ({
  type:"SEARCHDATA",
  payload: {
    ...todo
  }
});

const addTodoFailure = error => ({
  type:"APIFAILED",
  payload: {
    error
  }
});


export function decrement(idx){
  return{
   type:"UPDATE",
   payload:idx
}
}

export function incdata(){
return{
 type:'INCDATA'
}
}

export function Deletedata(idx){ 
 return{
    type:'DELETE',
    payload : idx
}


  

}

